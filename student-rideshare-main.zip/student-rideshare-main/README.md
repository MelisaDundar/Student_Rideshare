# Student-Rideshare

## To run the app on your phone


  - Download Expo Go 
  
  - Clone the respository 
    ```bash
    $ git clone https://github.com/TheTrailblazer09/student-rideshare.git
    ```
  
 - npm i to install all the packages
 
 - npx expo start --tunnel 
 
 - Scan the QR code 
 
 The app will open on your phone
